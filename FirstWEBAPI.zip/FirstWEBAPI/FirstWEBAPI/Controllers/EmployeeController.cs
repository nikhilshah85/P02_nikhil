﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using FirstWEBAPI.Models;
namespace FirstWEBAPI.Controllers
{
    public class EmployeeController : ApiController
    {
        [HttpGet]
        public Employee GetEmployee()
        {
            Employee empObj = new Employee()
            {
                empNo = 101,
                empName = "Karthik",
                empSalary = 50000,
                empSkills = new List<string>() { ".Net", "Management", "HR", "Team Management" },
                isPermenant = true

            };
            return empObj;
        }


    }
}
