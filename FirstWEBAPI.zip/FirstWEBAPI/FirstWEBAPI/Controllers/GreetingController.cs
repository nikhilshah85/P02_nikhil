﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace FirstWEBAPI.Controllers
{
    public class GreetingController : ApiController
    {
        //[HttpGet]
        //public string GetGreetUser()
        //{
        //    return "Hello and Welcome to WEBAPI";
        //}

        //[HttpGet]
        //public string GetGreetUser(string gname)
        //{
        //    return "Hello and Welcome to WEBAPI" + gname;
        //}



        [HttpGet]
        public Dictionary<int,string> GetTechnologies()
        {

            Dictionary<int, string> myFriends = new Dictionary<int, string>();
            myFriends.Add(101, "Abc");
            myFriends.Add(102, "XYZ");
            myFriends.Add(103, "PQR");
            myFriends.Add(104, "AMD");
            myFriends.Add(105, "AST");
            myFriends.Add(106, "GST");
            //List<string> techList = new List<string>();
            //techList.Add(".Net");
            //techList.Add("Angular");
            //techList.Add("React");
            //techList.Add("Node");
            //techList.Add("JSON");
            //techList.Add("WCF");

            return myFriends;
        }



    }
}
