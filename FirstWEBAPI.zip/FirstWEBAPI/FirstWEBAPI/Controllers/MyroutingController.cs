﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace FirstWEBAPI.Controllers
{
    public class MyroutingController : ApiController
    {

        [HttpGet]
        [Route("api/myrouting/methodone")]
       
        public string GetHello()
        {
            return "Hello and Welcome";
        }

        [HttpGet]
        [Route("api/myrouting/methodtwo")]
        public string Hey()
        {
            return "Hey i m method 2";
        }




    }
}
