﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using FirstWEBAPI.Models;

namespace FirstWEBAPI.Controllers
{
    public class BankingController : ApiController
    {

        Accounts acc = new Accounts();
        public BankingController()
        {
            acc.GetAccounts();
        }


        [HttpGet]
        public List<Accounts> GetAccounts()
        {
            return acc.GetAccounts();
        }

        [HttpGet]
        public Accounts GetAccountByNo(int accNo)   
        {
           return acc.GetAccountByNo(accNo);
        }



        [HttpDelete]
        public List<Accounts> DeleteAccount(int accNo)
        {
           return acc.DeleteByAccNo(accNo);
        }
        [HttpPut]
        public List<Accounts> Put(int accNo,[FromBody] Accounts newaccountvalues)
        {
            return acc.UpdateByAccNo(accNo, newaccountvalues);
        }

        [HttpPost]
        public List<Accounts> Post([FromBody]Accounts newaccount)
        {
            return acc.AddNewAccount(newaccount);
        }

        [HttpGet]
        [Route("api/accountaccending")]
        public List<Accounts> GetAccountsBySortedType()
        {
            return acc.SortByAccType();
        
        }

        [HttpGet]
        [Route("api/total")]
        public int GetTotalAccounts()
        {
            return acc.GetTotalAccounts();
        }



    }
}
