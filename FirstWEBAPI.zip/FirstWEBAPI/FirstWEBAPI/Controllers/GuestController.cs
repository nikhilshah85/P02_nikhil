﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace FirstWEBAPI.Controllers
{
    public class GuestController : ApiController
    {
       static Dictionary<int,string> guestList = new Dictionary<int, string>();

        public GuestController()
        {
            if (guestList.Count ==0)
            {
                guestList.Add(501,"Steve");
                guestList.Add(502,"Bill");
                guestList.Add(503,"Mark");
                guestList.Add(504,"Elon");
                guestList.Add(505,"Jeff");
            }                      
        }

        [HttpGet]
        public Dictionary<int, string> GetAllGuest()
        {
            return guestList;
        }
        [HttpGet]
        public string GetGuest(int id)
        {

            var g = guestList.Where(x => x.Key == id).Single();


            //    //var getIndex = (from g in guestList
            //    //                where g.Key == id
            //    //                select g).Single();

            return g.Value;
        }

        //[HttpPost]
        //public int Post(string newguest)
        //{
        //    guestList.Add(newguest);
        //    return 1;
        //}
        //[HttpDelete]
        //public int Delete(int id)
        //{
        //    guestList.RemoveAt(id);
        //    return 1;
        //}
        //[HttpPut]
        //public int Put(int id, string newvalue)
        //{
        //    guestList[id] = newvalue;
        //    return 1;
        }


}


