﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FirstWEBAPI.Models
{
    public class Accounts
    {

        static List<Accounts> accList = new List<Accounts>();

        public Accounts()
        {
           
        }

        public List<Accounts> GetAccounts()
        {
            if (accList.Count == 0)
            {


                accList = new List<Accounts>() {
                new Accounts(){ accNo=101, accName = "Priya", accBalance = 5000, accType = "Savings"},
                new Accounts(){ accNo=102, accName = "Riya", accBalance = 15000, accType = "Current"},
                new Accounts(){ accNo=103, accName = "Jiya", accBalance = 25000, accType = "Savings"},
                new Accounts(){ accNo=104, accName = "Dia", accBalance = 52000, accType = "Current"},
                new Accounts(){ accNo=105, accName = "Nikhil", accBalance = 12000, accType = "Savings"},
                new Accounts(){ accNo=106, accName = "Nikita", accBalance = 18000, accType = "Current"}
            };
            }
            return accList;

        }

        public Accounts GetAccountByNo(int accNo)
        {
            var acc = (from a in accList
                       where a.accNo == accNo
                       select a).Single();

            return acc;
        }

        public List<Accounts> DeleteByAccNo(int accNo)
        {
            var acc = (from a in accList
                       where a.accNo == accNo
                       select a).Single();
            accList.Remove(acc);
            return accList;
        }

        public List<Accounts> UpdateByAccNo(int accNo,Accounts newaccountvalues)
        {
            var acc = (from a in accList
                       where a.accNo == accNo
                       select a).Single();

            acc.accName = newaccountvalues.accName;
            acc.accType = newaccountvalues.accType;
            acc.accBalance = newaccountvalues.accBalance;

            return accList;
        }

        public List<Accounts> AddNewAccount(Accounts newacc)
        {
            accList.Add(newacc);
            return accList;
        }


        public List<Accounts> SortByAccType()
        {
            var acc = from a in accList
                      orderby a.accType
                      select a;
            return acc.ToList();
        }

        public List<Accounts> FilterByAccType(string type)
        {
            var acc = from a in accList
                      where a.accType == type
                      select a;
            return acc.ToList();
        }

        public List<Accounts> FilterByBalance()
        {
            var acc = from a in accList
                      where a.accBalance > 15000
                      select a;

            return acc.ToList();
        }

        public int GetTotalAccounts()
        {
            var totalAccounts = (from a in accList
                                 select a.accNo).Count();

            return totalAccounts;
        }
        public double TotalOfBalance()
        {
            var acc = (from a in accList
                       select a.accBalance).Sum();

            return acc;
        }


        public int accNo { get; set; }
        public string accName { get; set; }
        public double accBalance { get; set; }
        public string accType { get; set; }
    }
}