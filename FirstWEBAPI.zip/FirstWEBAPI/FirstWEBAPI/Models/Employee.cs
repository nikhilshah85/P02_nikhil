﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FirstWEBAPI.Models
{
    public class Employee
    {
        public string empName { get; set; }
        public int empNo { get; set; }

        public double empSalary { get; set; }
        public bool isPermenant { get; set; }

        public List<string> empSkills { get; set; }

    }
}